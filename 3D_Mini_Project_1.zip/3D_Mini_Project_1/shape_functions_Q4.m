
function [N] = shape_functions_Q4(p)
syms xi eta zeta


 if p==10   % tetrahedral_shape_functions_10_nodes(xi, eta, zeta)
    N1 = (1 - xi - eta - zeta) * (1 - 2*xi - 2*eta - 2*zeta);
    N2 = xi * (2*xi - 1);
    N3 = eta * (2*eta - 1);
    N4 = zeta * (2*zeta - 1);
    N5 = 4 * xi * (1 - xi - eta - zeta);
    N6 = 4 * xi * eta;
    N7 = 4 * eta * (1 - xi - eta - zeta);
    N8 = 4 * eta * zeta;
    N9 = 4 * zeta * (1 - xi - eta - zeta);
    N10 = 4 * zeta * xi;

    N=[N1;N2;N3;N4;N5;N6;N7;N8;N9; N10];


 elseif p==4
   N = zeros(4, 1);
   N1 = 0.25 * (1 - xi) * (1 - eta);
   N2 = 0.25 * (1 - xi) * (1 + eta);
   N3 = 0.25 * (1 + xi) * (1 + eta);
   N4 = 0.25 * (1 + xi) * (1 - eta);
    
   % Shape functions
   N=[N1;N2;N3;N4];


 elseif p==3
     N = zeros(3,1);

     N1 =1-xi-eta;
     N2 = xi;
     N3 = eta;
     
     N=[N1;N2;N3];
     
    % for 6 nodes
    % syms xi eta;
 elseif p==6
N1 = (2*xi - 1)*xi;
N2 = 4*(1 - xi - eta)*xi;
N3 = (2*(1 - xi - eta) - 1)*(1 - xi - eta);
N4 = 4*eta*(1 - xi - eta);
N5 = (2*eta - 1)*eta;
N6 = 4*xi*eta;

N=[N1;N2;N3;N4;N5;N6];
 % for 9 nodes

 elseif p==9
% Define shape functions N1 to N9
% syms xi eta; 
% Define symbolic variables xi and eta

N1 = 0.25*xi * (xi - 1) * eta * (eta - 1) ;
N2 = -0.5*xi * (xi - 1) * (eta + 1) * (eta - 1);
N3 = 0.25*xi * (xi - 1) * eta * (eta + 1);
N4 = - 0.5*(xi + 1) * (xi - 1) * eta * (eta + 1);
N5 = 0.25*xi * (xi + 1) * eta * (eta + 1);
N6 = -0.5*xi * (xi + 1) * (eta + 1) * (eta - 1);
N7 = 0.25*xi * (xi + 1) * eta * (eta - 1);
N8 = - 0.5*(xi + 1) * (xi - 1) * eta * (eta - 1);
N9 = (xi + 1) * (xi - 1) * (eta + 1) * (eta - 1);

N=[N1;N2;N3;N4;N5;N6;N7;N8;N9];


    
    % B[1:3:end] = to be implemented as discussed with TA 
end

end

