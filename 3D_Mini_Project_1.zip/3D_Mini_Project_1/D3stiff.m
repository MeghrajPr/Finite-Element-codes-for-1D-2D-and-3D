clear
clc
% test = [1 2 3; 4 5 6; 7 8 9]
syms N1x N2x N3x N1y N2y N3y N1z N2z N3z
test = [N1x N2x N3x; N1y N2y N3y; N1z N2z N3z]
[rows, cols] = size(test);
S = sym(zeros(rows*2,cols*3));
     S(1,1:3:end)= test(1,:);
     S(2,2:3:end)= test(2,:);
     S(3,3:3:end)= test(3,:);
      
for i = 1:cols
    S(rows+1,1 + (i - 1) * 3) = S(2,2 + (i - 1) * 3); % Adding to 4th row
    S(rows+1,2 + (i - 1) * 3) = S(1,1 + (i - 1) * 3); % Adding to 4th row
    S(rows+2,2 + (i - 1) * 3) = S(3,3 + (i - 1) * 3); % Adding to 5th row
    S(rows+2,3 + (i - 1) * 3) = S(2,2 + (i - 1) * 3); % Adding to 5th row
    S(rows+3,1 + (i - 1) * 3) = S(3,3 + (i - 1) * 3); % Adding to 6th row
    S(rows+3,3 + (i - 1) * 3) = S(1,1 + (i - 1) * 3); % Adding to 6th row
end
S
