
function[K,ds,M, dm] = FormStiffHW_3D(p,ngauss,X1) % This function calculates the local stiffness matrix
syms xi eta zeta

[N] = shape_functions_Q4(p);

 K = zeros(3*p,3*p);
  
 M = zeros(3*p,3*p);
  
 E = 1.5e11;
 v = 0.3;
 ro = 2000;

% Calculate coefficients
coeff = E / ((1 + v) * (1 - 2 * v));

% Define the matrix D for 3D element
D = coeff * [
    1 - v, v, v, 0, 0, 0;
    v, 1 - v, v, 0, 0, 0;
    v, v, 1 - v, 0, 0, 0;
    0, 0, 0, (1 - 2 * v) / 2, 0, 0;
    0, 0, 0, 0, (1 - 2 * v) / 2, 0;
    0, 0, 0, 0, 0, (1 - 2 * v) / 2];

 %J1=jacobian
     B= [diff(N',xi); diff(N',eta); diff(N',zeta)]; % diff it saparatly
     J1 = B*X1;
     d=det(J1);

     [rows, cols] = size(B);
     S = sym(zeros(rows*2,cols*3));
     S(1,1:3:end)= B(1,:);
     S(2,2:3:end)= B(2,:);
     S(3,3:3:end)= B(3,:);
      
for i = 1:cols
    S(rows+1,1 + (i - 1) * 3) = S(2,2 + (i - 1) * 3); % Adding to 4th row
    S(rows+1,2 + (i - 1) * 3) = S(1,1 + (i - 1) * 3); % Adding to 4th row
    S(rows+2,2 + (i - 1) * 3) = S(3,3 + (i - 1) * 3); % Adding to 5th row
    S(rows+2,3 + (i - 1) * 3) = S(2,2 + (i - 1) * 3); % Adding to 5th row
    S(rows+3,1 + (i - 1) * 3) = S(3,3 + (i - 1) * 3); % Adding to 6th row
    S(rows+3,3 + (i - 1) * 3) = S(1,1 + (i - 1) * 3); % Adding to 6th row
end

     ds = S'*D*S*d;

     % For Mass mtarix
     [rows, cols] = size(N');
     Q = sym(zeros(rows*3,cols*3))
     Q(1,1:3:end)= N(1,:);
     Q(2,2:3:end)= N(2,:);
     Q(3,3:3:end)= N(3,:);

    dm = ro*Q'*Q;
   

[lc_coord, weight] = Gausst(ngauss);

for k =1:ngauss
    for j = 1:ngauss
        for i= 1:ngauss
            n =  size(weight,1);

        K = K +(weight(i)*subs(subs(subs(ds,xi,[lc_coord(i)]),eta,[lc_coord(j)]),zeta,[lc_coord(k)]));
              
        K = double(K);

        M = M +((weight(k)*(weight(j)*(weight(i)*subs(subs(subs(dm,xi,[lc_coord(i)]),eta,[lc_coord(j)]),zeta,[lc_coord(k)])))));

        M = double(M);

        end
   
    end

end



