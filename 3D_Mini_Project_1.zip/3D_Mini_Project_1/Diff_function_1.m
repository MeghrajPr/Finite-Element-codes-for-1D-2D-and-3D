syms xi eta zeta

p=10;

    N1 = (1 - xi - eta - zeta) * (1 - 2*xi - 2*eta - 2*zeta);
    N2 = xi * (2*xi - 1);
    N3 = eta * (2*eta - 1);
    N4 = zeta * (2*zeta - 1);
    N5 = 4 * xi * (1 - xi - eta - zeta);
    N6 = 4 * xi * eta;
    N7 = 4 * eta * (1 - xi - eta - zeta);
    N8 = 4 * eta * zeta;
    N9 = 4 * zeta * (1 - xi - eta - zeta);
    N10 = 4 * zeta * xi;

    N=[N1;N2;N3;N4;N5;N6;N7;N8;N9; N10];

 K = zeros(3*p,3*p);
  
 M = zeros(3*p,3*p);
  
 E = 1.5e11;
 v = 0.3;
 ro = 2000;

% Calculate coefficients
coeff = E / ((1 + v) * (1 - 2 * v));

% Define the matrix D for 3D element
D = coeff * [
    1 - v, v, v, 0, 0, 0;
    v, 1 - v, v, 0, 0, 0;
    v, v, 1 - v, 0, 0, 0;
    0, 0, 0, (1 - 2 * v) / 2, 0, 0;
    0, 0, 0, 0, (1 - 2 * v) / 2, 0;
    0, 0, 0, 0, 0, (1 - 2 * v) / 2];

 %J1=jacobian
     B= [diff(N',xi); diff(N',eta); diff(N',zeta)] %