
syms xi eta zeta

p=10;

    N1 = (1 - xi - eta - zeta) * (1 - 2*xi - 2*eta - 2*zeta);
    N2 = xi * (2*xi - 1);
    N3 = eta * (2*eta - 1);
    N4 = zeta * (2*zeta - 1);
    N5 = 4 * xi * (1 - xi - eta - zeta);
    N6 = 4 * xi * eta;
    N7 = 4 * eta * (1 - xi - eta - zeta);
    N8 = 4 * eta * zeta;
    N9 = 4 * zeta * (1 - xi - eta - zeta);
    N10 = 4 * zeta * xi;

    N=[N1;N2;N3;N4;N5;N6;N7;N8;N9; N10];

 K = zeros(3*p,3*p);
  
 M = zeros(3*p,3*p);
  
 E = 1.5e11;
 v = 0.3;
 ro = 2000;

% Calculate coefficients
coeff = E / ((1 + v) * (1 - 2 * v));

% Define the matrix D for 3D element
D = coeff * [
    1 - v, v, v, 0, 0, 0;
    v, 1 - v, v, 0, 0, 0;
    v, v, 1 - v, 0, 0, 0;
    0, 0, 0, (1 - 2 * v) / 2, 0, 0;
    0, 0, 0, 0, (1 - 2 * v) / 2, 0;
    0, 0, 0, 0, 0, (1 - 2 * v) / 2];

 %J1=jacobian
     B= [diff(N',xi); diff(N',eta); diff(N',zeta)] % diff it saparatly
     % J1 = B*X1
     % d=det(J1)

     [rows, cols] = size(B);
     S = sym(zeros(rows*2,cols*3));
     S(1,1:3:end)= B(1,:);
     S(2,2:3:end)= B(2,:);
     S(3,3:3:end)= B(3,:);
      
for i = 1:cols
    S(rows+1,1 + (i - 1) * 3) = S(2,2 + (i - 1) * 3); % Adding to 4th row
    S(rows+1,2 + (i - 1) * 3) = S(1,1 + (i - 1) * 3); % Adding to 4th row
    S(rows+2,2 + (i - 1) * 3) = S(3,3 + (i - 1) * 3); % Adding to 5th row
    S(rows+2,3 + (i - 1) * 3) = S(2,2 + (i - 1) * 3); % Adding to 5th row
    S(rows+3,1 + (i - 1) * 3) = S(3,3 + (i - 1) * 3); % Adding to 6th row
    S(rows+3,3 + (i - 1) * 3) = S(1,1 + (i - 1) * 3); % Adding to 6th row
end

     ds = S'*D*S*d

     % For Mass mtarix
     [rows, cols] = size(N');
     Q = sym(zeros(rows*3,cols*3))
     Q(1,1:3:end)= N(1,:);
     Q(2,2:3:end)= N(2,:);
     Q(3,3:3:end)= N(3,:);

    dm = ro*Q'*Q;
   

[lc_coord, weight] = Gausst(ngauss);

for k =1:ngauss
    for j = 1:ngauss
        for i= 1:ngauss
            n =  size(weight,1);
            % [lc_coord(i)]
            % [lc_coord(j)]

        K = K +(weight(i)*subs(subs(subs(ds,xi,[lc_coord(i)]),eta,[lc_coord(j)]),zeta,[lc_coord(k)]));
              
        K = double(K);

        M = M +((weight(k)*(weight(j)*(weight(i)*subs(subs(subs(dm,xi,[lc_coord(i)]),eta,[lc_coord(j)]),zeta,[lc_coord(k)])))));

        M = double(M);

        end
   
    end

end