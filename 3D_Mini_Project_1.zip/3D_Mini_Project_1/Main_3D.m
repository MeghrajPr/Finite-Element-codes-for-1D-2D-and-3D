
%%
% Load data from files
clear
clc
% eleconnect = load('Pr1_4q_elecon.txt')
ele= readtable('RobotArm_elecon.txt');
eleconnect = table2array(ele)

% nel = int32(eleconnect(end, 1))

% nodes = load('Pr1_4q_nodes.txt');
n = readtable('RobotArm_nodes.txt');
nodes = table2array(n)

 % boundterms = [1 1 5; 1 5 6; 1 6 7; 1 7 8; 1 8 9; 1 9 10; 1 10 11; 1 11 12; 1 12 13; 1 13 14; 1 14 2;
 %              2 2 15; 2 15 16; 2 16 17; 2 17 3; 3 3 18; 3 18 19; 3 19 20; 3 20 21; 3 21 22; 3 22 23; 3 23 24;
 %              3 24 25; 3 25 26; 3 26 27; 3 27 4; 4 4 28; 4 28 29; 4 29 30; 4 30 1];

ngauss = 4;

     tetramesh(eleconnect, nodes, 'FaceColor','green')
     view(30,30)

% s = 9;
% q0 = -15;

% Write logic for boundterm
% lpf = [1 s 0; 2 3 q0];
% 
% f = zeros(size(boundterms, 1), 3);
% for i = 1:size(boundterms, 1)
%     if boundterms(i, 1) == 1 || boundterms(i, 1) == 4
%         f(i, 1) = boundterms(i, 2) ; % indices start from 0
%         f(i, 2) = 1;
%         f(i, 3) = 0;
%     end
% end
% 
% fdof = f(any(f, 2), :)
     %% 3D Vector
    nel = size(eleconnect, 1); % Total number of elements
    nnodes = size(nodes, 1);   % Total number of nodes
    ndof = 3; 
    tdof = ndof*nnodes;
    p = 10 ; % for 10 Noded element
    edof = ndof*p;

    I = zeros(tdof,1); J = zeros(tdof,1);
    X = zeros(tdof,1); Xm = zeros(tdof,1);
    ntriplets = 0; nloadvec = 0;
    
    Kstiff = zeros(3*nnodes, 3*nnodes);
    Mstiff = zeros(3*nnodes, 3*nnodes);
    Fvec = zeros(3*nnodes, 1);
    
     for i = 1:nel
         enodes = eleconnect(i, :);
         % To get coordinates of nodes
            X1 = [];
            for j = enodes
                x1 = nodes(j, :);
                X1 = [X1; x1];
            end

        % local Stifness Matrix

       tic
       [K,~,M,~] = FormStiffHW_3D(p,ngauss,X1);
       toc

       disp(['element', num2str(i), ' is 10 Noded Element']);
       e1 = [enodes(1) * 3-2, enodes(1) * 3-1, enodes(1) * 3 , enodes(2) * 3-2, enodes(2) * 3-1, enodes(2) * 3, ...
       enodes(3) * 3-2, enodes(3) * 3-1, enodes(3) * 3 , enodes(4) * 3-2, enodes(4) * 3-1, enodes(4) * 3 ...
       enodes(5) * 3-2, enodes(5) * 3-1, enodes(5) * 3 , enodes(6) * 3-2, enodes(6) * 3-1, enodes(6) * 3 ...
       enodes(7) * 3-2, enodes(7) * 3-1, enodes(7) * 3 , enodes(8) * 3-2, enodes(8) * 3-1, enodes(8) * 3 ...
       enodes(9) * 3-2, enodes(9) * 3-1, enodes(9) * 3 , enodes(10) * 3-2, enodes(10) * 3-1, enodes(10) * 3];
      
       for krow = 1:tdof
           for kcol = 1:tdof
               ntriplets = ntriplets+1;
               I(ntriplets) = e1(krow)
               J(ntriplets) = e1(kcol)
               X(ntriplets) = K(krow, kcol);
               Xm(ntriplets) = M(krow, kcol);

           end
       end


             % Assembly based on enodes - using sparse representation
       Kstiff(e1, e1) = sparse(I(1:ntriplets), J(1:ntriplets), X(1:ntriplets), tdof,tdof);
       % Mstiff(e1, e1) = sparse(I(1:ntriplets), J(1:ntriplets), Xm(1:ntriplets), tdof,tdof);


       % Default way of calculating global stiffness matrix
       % Kstiff(e1, e1) = Kstiff(e1, e1) + K;
       % 
       % Mstiff(e1, e1) = Kstiff(e1, e1) + M;

     end 
     

     %% %% 2D Scalar Problems

    nnodes = int32(nodes(end, 1))

    Kstiff = zeros(nnodes, nnodes);
    Fvec = zeros(nnodes, 1);

     for i = 1:nel
         p = eleconnect(i, 2)
            if p == 4   % Quadrilateral element       
            disp(['element', num2str(i), ' is Quad']);            
            enodes = eleconnect(i, 3:end-1)

           % To get coordinates of nodes
            X1 = [];
            for j = enodes
                x1 = nodes(j, 2:end);
                X1 = [X1; x1];
            end

%             % X1 = zeros(p, 2);
%             % for j = 1:p
%             %     X1(j, :) = nodes(enodes(j), 2:3)
%             % end
            K = FormStiffHW_2D(p,ngauss,X1);
            Kstiff(enodes, enodes) = Kstiff(enodes, enodes) + K;
            Kstiff = double(Kstiff);
        % end
    
          f = FormNodLoadHW_2D(lpf, p, ngauss, X1,boundterms,enodes)
          f = double(f)

    % % Update Fvec based on enodes
       Fvec(enodes, 1) = Fvec(enodes, 1) + f;

    else
            % Triangular element    
            % compute local Stiffness matrix for Tri element
            disp(['element', num2str(i), ' is Tri']);
            enodes = eleconnect(i, 3:5)

            % To get coordinates of nodes
            X1 = [];
            for j = enodes
                x1 = nodes(j, 2:end)
                X1 = [X1; x1];
            end

               [~,dk]=FormStiffHW_2D(p,ngauss,X1)
               K = 0.5*dk
             Kstiff(enodes, enodes) = Kstiff(enodes, enodes) + K

              f = FormNodLoadHW_2D(lpf, p, ngauss, X1,boundterms,enodes)
                double(f)

    % Update Fvec based on enodes
     Fvec(enodes , 1) = Fvec(enodes, 1) + f
        end
    end
dof = zeros(1, nnodes, 'int32');
 ndof = 1;  % Scalar field problems
 tdof = nnodes;
 count = 1;
 for i = 1:size(fdof, 1)  % fixeddofs=[0,1,0]
     for j = 1:ndof
        if fdof(i, j+1) == 1
             dof(count) = fdof(i, 1) * ndof + j - 1;
             count = count + 1;
         end
    end
end
 dof = dof(1:count-1)
 freedofs = setdiff(1:tdof, dof)
% 
% % Step 4: Solve KU = F
 U = zeros(tdof, 1)
% 
 if isempty(dof)
     disp('solving a matrix');
     U = linsolve(Kstiff, zeros(size(Kstiff, 1), 1));
 else
     U(dof(1)) = fdof(1, end)
     U(freedofs) = linsolve(Kstiff(freedofs, freedofs), Fvec(freedofs) - Kstiff(freedofs, dof) * U(dof))
 end
 Fvec
% % F = Kstiff * U
% 
%% %% 2D Vector Problems

    nnodes = int32(nodes(end, 1))

    Kstiff = zeros(2*nnodes, 2*nnodes);
    Fvec = zeros(2*nnodes, 1);
    
     for i = 1:nel
         p = eleconnect(i, 2);
         enodes = eleconnect(i, 3:end-1);
         % To get coordinates of nodes
            X1 = [];
            for j = enodes
                x1 = nodes(j, 2:end);
                X1 = [X1; x1];
            end
                if p == 4   % Quadrilateral element
                disp(['element', num2str(i), ' is Quad']);
                e1 = [enodes(1) * 2-1, enodes(1) * 2 , enodes(2) * 2-1, enodes(2) * 2, ...
                    enodes(3) * 2-1, enodes(3) * 2 , enodes(4) * 2-1 ,enodes(4) * 2];

            elseif p == 6  % 6 Noded element
                disp(['element', num2str(i), ' is 6 Noded Element']);
                e1 = [enodes(1) * 2-1, enodes(1) * 2 , enodes(2) * 2-1, enodes(2) * 2 , ...
                    enodes(3) * 2-1, enodes(3) * 2, enodes(4) * 2-1, enodes(4) * 2 , ...
                    enodes(5) * 2-1, enodes(5) * 2 , enodes(6) * 2-1, enodes(6) * 2];

            elseif p == 9 % 9 Noded element
                disp(['element', num2str(i), ' is 9 Noded Element']);
                e1 = [enodes(1) * 2-1, enodes(1) * 2 , enodes(2) * 2-1, enodes(2) * 2 , ...
                    enodes(3) * 2-1, enodes(3) * 2, enodes(4) * 2-1, enodes(4) * 2 , ...
                    enodes(5) * 2-1, enodes(5) * 2 , enodes(6) * 2-1, enodes(6) * 2 , ...
                    enodes(7) * 2-1, enodes(7) * 2 , enodes(8) * 2-1, enodes(8) * 2, ...
                    enodes(9) * 2-1, enodes(9) * 2 ];
                end
                K = FormStiffHW_2D_beam(p,ngauss,X1);

                Kstiff(e1, e1) = Kstiff(e1, e1) + K


% %           f = FormNodLoadHW_2D_beam(lpf, p, ngauss, X1,boundterms,enodes);
% %     %   f = double(f)
      end
     % end