function [lc_coord, weight]=Gausst(ngauss)

    % Setup Gaussian Coefficients and Evaluation Points for triangular
    % domain. For a given number of evaluations (total number of Gauss
    % points), return the the coordinates and the weights in the local
    % coordinate.    
            
    if ngauss == 4
data = [0.58541020 	0.13819660 	0.13819660 0.041666667;
0.13819660 	0.58541020 	0.13819660 	0.041666667
0.13819660 	0.13819660 	0.58541020 	0.041666667
0.13819660 	0.13819660 	0.13819660 	0.041666667];
        lc_coord = data(:,1:3);
        weight = data(:,end);
    elseif ngauss == 8
        data = [0.01583591 	0.328054697 	0.328054697 	0.023087995
0.328054697 	0.01583591 	0.328054697 	0.023087995
0.328054697 	0.328054697 	0.01583591 	0.023087995
0.328054697 	0.328054697 	0.328054697 	0.023087995
0.679143178 	0.106952274 	0.106952274 	0.018578672
0.106952274 	0.679143178 	0.106952274 	0.018578672
0.106952274 	0.106952274 	0.679143178 	0.018578672
0.106952274 	0.106952274 	0.106952274 	0.018578672 ];
        lc_coord = data(:,1:3);
        weight = data(:,end);
    else
        error('Wrong choice of gauss points for triangular domain')
    end

end